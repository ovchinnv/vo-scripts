#!/bin/tcl
# Script for performing TMD-TCL in NAMD using TCLForces
# Files: tmd.tcl (this file -- main routine) & tmdAux.tcl (subroutines)
# Author: Victor Ovchinnikov, Harvard University/MIT, June 2007

# Orientation & forcing are allowed on different sets of atoms, specified in occupancy & beta, respectively;
# this will lead to net torques and forces on the molecule, however, because contributions arising from the 
# rotation matrix derivatives are in this case nonzero (but are not computed here to save time)
# drmsd.tcl is a modification of tmd.tcl which restrains the difference between RMSD to two specified structures

############################################################################
source tmdAux7.tcl;
#
# take care of uninitialized variables -- these are defaults
if { ![info exists TMDBMD] } {set TMDBMD 0;}
if { ![info exists TMDdK] } {set TMDdK 0.0;}
if { ![info exists TMDfinalK] } {set TMDfinalK $TMDk;}
if { ![info exists TMDforcesOutFreq] } {set TMDforcesOutFreq 0;}
if { ![info exists TMDorient]} {set TMDorient 1};
if { ![info exists TMDorientFreq]} {set TMDorientFreq 1};
if { ![info exists TMDmass]} {set TMDmass 1};
if { ![info exists TMDforcesOn]} {set TMDforcesOn 1};

# PDB FILE STANDARD:
#   1. |    1 -  6    |   A6    | Record ID (eg ATOM, HETATM)       
#   2. |    7 - 11    |   I5    | Atom serial number                            
#   -  |   12 - 12    |   1X    | Blank                                         
#   3. |   13 - 16    |   A4    | Atom name (eg " CA " , " ND1")   
#   4. |   17 - 17    |   A1    | Alternative location code (if any)            
#   5. |   18 - 20    |   A3    | Standard 3-letter amino acid code for residue 
#   -  |   21 - 21    |   1X    | Blank                                         
#   6. |   22 - 22    |   A1    | Chain identifier code                         
#   7. |   23 - 26    |   I4    | Residue sequence number                       
#   8. |   27 - 27    |   A1    | Insertion code (if any)                       
#   -  |   28 - 30    |   3X    | Blank                                         
#   9. |   31 - 38    |  F8.3   | Atom's x-coordinate                         
#  10. |   39 - 46    |  F8.3   | Atom's y-coordinate                         
#  11. |   47 - 54    |  F8.3   | Atom's z-coordinate                         
#  12. |   55 - 60    |  F6.2   | Occupancy value for atom                      
#  13. |   61 - 66    |  F6.2   | B-value (thermal factor)                    

set TMDatoms {};
set TMDatoms2 {};
set TMDtargetCoor1 {};
set TMDtargetCoor2 {};
set targetcoor1 {}; # we need this to be static, therefore global
set targetcoor2 {};

set TMDforcedFlags {}; # contains atoms for orientation
set TMDorientFlags {}; # contains atoms for forcing
set TMDforcedAtoms 0 ;
set TMDorientAtoms 0;
set TMDforcesOut 0; # file ID of force output file
set TMDwork 0; #work done by TMD restraint

set fid1 [open $TMDfile1 r] ; # read first target file
foreach line1 [split [read $fid1] \n] {
    set recordID1 [string trim [string range $line1 0 5]]
    set atomnum1  [string trim [string range $line1 6 10]]
    set atomname1 [string trim [string range $line1 12 15]]
    set resname1  [string trim [string range $line1 17 19]]
    set resnum1   [string trim [string range $line1 12 15]]
    set xcrd1     [string trim [string range $line1 30 37]]
    set ycrd1     [string trim [string range $line1 38 45]]
    set zcrd1     [string trim [string range $line1 46 53]]
    set occu1     [string trim [string range $line1 54 59]]
    set beta1     [string trim [string range $line1 60 65]]
    set segid1    [string trim [string range $line1 72 75]]
    if { [string equal $recordID1 {ATOM}] } { ;#process only ATOM fields
# different selection criteria can be wired below
      if { ( $occu1 == 1.0 ) || ( $beta1 == 1.0 ) } { ;# orientation based on occupancy; forcing based on beta
        lappend TMDatoms $atomnum1
        lappend TMDtargetCoor1 $xcrd1 $ycrd1 $zcrd1
        addatom $atomnum1 ;
        if { $occu1 == 1 } {
         lappend TMDorientFlags 1.0;
         incr TMDorientAtoms
        } else {
         lappend TMDorientFlags 0.0;
        } 
        if { $beta1 == 1 } {
#different criteria:   if { ([lsearch -exact "ATP MG" $segid] > -1) && ([string index $atomname 1] != "H") }
         lappend TMDforcedFlags 1.0 ;# want to orient the whole structure, but apply force only to the ATP !
         incr TMDforcedAtoms;
        } else {
         lappend TMDforcedFlags 0.0;
        }
       }
    }
}
close $fid1;# done with file
#
set fid2 [open $TMDfile2 r] ; # read second target file
foreach line2 [split [read $fid2] \n] {
# second file
    set recordID2 [string trim [string range $line2 0 5]]
    set atomnum2  [string trim [string range $line2 6 10]]
    set atomname2 [string trim [string range $line2 12 15]]
    set resname2  [string trim [string range $line2 17 19]]
    set resnum2   [string trim [string range $line2 12 15]]
    set xcrd2     [string trim [string range $line2 30 37]]
    set ycrd2     [string trim [string range $line2 38 45]]
    set zcrd2     [string trim [string range $line2 46 53]]
    set occu2     [string trim [string range $line2 54 59]]
    set beta2     [string trim [string range $line2 60 65]]
    set segid2    [string trim [string range $line2 72 75]]
    if { [string equal $recordID2 {ATOM}] } { ;#process only ATOM fields
      if { ( $occu2 == 1.0 ) || ( $beta2 == 1.0 ) } { ;# orientation based on occupancy; forcing based on beta
        lappend TMDatoms2 $atomnum2
        lappend TMDtargetCoor2 $xcrd2 $ycrd2 $zcrd2
       };#if
    };#if
};#foreach
close $fid2;# done with file
# compare two lists
foreach a1 $TMDatoms a2 $TMDatoms2 {
 if {$a1 != $a2} {
  error "TMD-TCL error: TMD atoms in the two structures do not match"
  exit
 }
};#foreach
#
set TMDnatom [llength $TMDatoms];
if { ($TMDnatom == 0) || ($TMDforcedFlags == 0) || ($TMDorientFlags == 0) } {
    set TMDon 0
    print "TMD-TCL WARNING: no TMD atoms found, no forcing, or no orientation atoms found!";
} else {
    set TMDon 1
    print "TMD-TCL: $TMDnatom TMD atoms found"
    print "TMD-TCL: orienting structure based on $TMDorientAtoms atoms"; 
    print "TMD-TCL: forcing $TMDforcedAtoms atoms";
    print "TMD-TCL: force constant is $TMDk kcal/mol/A^2"; 
    if { [file exists $TMDlogFile] } { file copy -force -- "$TMDlogFile" "${TMDlogFile}.BAK"; }
    set TMDout [open $TMDlogFile w+];
    puts $TMDout "%TMD-TCL: $TMDnatom TMD atoms found"
    puts $TMDout "%TMD-TCL: orienting structure based on $TMDorientAtoms atoms"; 
    puts $TMDout "%TMD-TCL: forcing $TMDforcedAtoms atoms"
    puts $TMDout "%TMD_TCL: force constant is $TMDk kcal/mol/A^2"; 
    if { $TMDmass > 0 } {
     print "TMD-TCL: will use mass-weighted coordinates"
     puts $TMDout "%TMD-TCL: will use mass-weighted coordinates"
    }
# do we need to get TargetRMSD from an existing log file?
   if { $TMDtargetRMS == -999 } {
    set TMDoutOld [open $TMDlogFileOld r];
    while { [gets $TMDoutOld line] > -1 } {
      set lastline [split $line "\t"];
     }
     close $TMDoutOld
     set TMDtargetRMS [lindex $lastline 4];
     puts $TMDout "%TMD-TCL: Obtained initial target RMS value from file $TMDlogFileOld: $TMDtargetRMS";flush $TMDout;
   };  
# do we need to get force constant from an existing log file?
   if { $TMDk == -999 } {
    set TMDoutOld [open $TMDlogFileOld r];
    while { [gets $TMDoutOld line] > -1 } {
      set lastline [split $line "\t"];
     }
     close $TMDoutOld
     set TMDk [lindex $lastline 1];
     puts $TMDout "%TMD-TCL: Obtained force constant value from file $TMDlogFileOld: $TMDk";flush $TMDout;
   };  
    puts $TMDout "%TS \t k \t Force \t Current RMSD \t Target RMSD \t Final RMSD \t Work"; flush $TMDout;
}
# now open file for forces output
if { $TMDforcesOutFreq > 0 } {
    if { [file exists $TMDforcesOutFile] } { file copy -force -- "$TMDforcesOutFile" "${TMDforcesOutFile}.BAK"; }
    set TMDforcesOut [open $TMDforcesOutFile w+];
    puts $TMDforcesOut "%TMD-TCL: logging forces on $TMDforcedAtoms atoms every $TMDforcesOutFreq steps";
    puts $TMDforcesOut "$TMDforcedAtoms"
    puts $TMDforcesOut "$TMDatoms" ;# list all tmd atoms
    puts $TMDforcesOut "$TMDorientFlags" ;# list all orient atoms
    puts $TMDforcesOut "$TMDforcedFlags" ;# list all forced atoms
    }
###########################################################################################################
proc calcforces { } {

 global TMDatoms TMDorient TMDorientFreq TMDBMD TMDdRMS TMDfirstTstep TMDtargetCoor1 TMDtargetCoor2 TMDmass;
 global TMDtargetRMS TMDfinalRMS TMDk TMDfinalK TMDdK TMDout TMDon TMDprintFreq TMDdt TMDforcedFlags; 
 global TMDorientFlags TMDforcesOn targetcoor1 targetcoor2;
 global TMDforcesOutFreq TMDforcesOut TMDwork;
 global oldForceLog; # for work computation

 if { $TMDon == 1 } { ;
 
  set currentcoor {};
  loadcoords coor;
  foreach {atom} $TMDatoms { 
   foreach {x y z} $coor($atom) {break;}
   lappend currentcoor $x $y $z ;
  }
 
  set forcelist {}; # used only if forces are output

  set timestep [getstep];
  set dtimestep [expr {$timestep-$TMDfirstTstep}];
#puts $TMDout "$timestep $TMDfirstTstep"
  if { $dtimestep == 0 }  {
   set oldForceLog 0.0
   set oflags {};
   set fflags {};
   set fflagsum 0.0;
   if { $TMDmass > 0 } {
#  at the first simulation step, update flag arrays for mass-weighting
    loadmasses mass
#  
    foreach oflag $TMDorientFlags fflag $TMDforcedFlags atom $TMDatoms {
     lappend oflags [expr {$oflag * $mass($atom)}];
     lappend fflags [expr {$fflag * $mass($atom)}];
     set fflagsum [expr {$fflagsum + $fflag * $mass($atom)}];
    };#foreach
    set TMDorientFlags $oflags
    set TMDforcedFlags $fflags
   } else { ;# TMDmass
    foreach fflag $TMDforcedFlags { set fflagsum [expr {$fflagsum + $fflag}]; }
   } ; #TMDmass
   set fflagsum [expr {1.0/$fflagsum}];    
   set TMDforcedFlags [vecscale $fflagsum $TMDforcedFlags];
# note: there is no need to normalize the orientflags; they are normalized on the fly in the rmsd/best-fit routines
  } ;# dtimestep
#
#puts $TMDout "$TMDtargetCoor1"
#puts $TMDout "$TMDtargetCoor2"
#
  if { ($TMDorient == 1) && ($dtimestep % $TMDorientFreq == 0) } {; # then orient
   set targetcoor1 [RMSBestFit $TMDtargetCoor1 $currentcoor $TMDorientFlags]; # use orientation atoms only
   set targetcoor2 [RMSBestFit $TMDtargetCoor2 $currentcoor $TMDorientFlags]; # second structure
  }
#
  set currentRMS1 [rmsd $currentcoor $targetcoor1 $TMDforcedFlags]; # use forced atoms in the computation of force
  set currentRMS2 [rmsd $currentcoor $targetcoor2 $TMDforcedFlags];
  set currentRMS  [expr {$currentRMS1 - $currentRMS2}];
  if { $TMDtargetRMS == -99 } { set TMDtargetRMS $currentRMS };
#
  set dRMS 0.0;
#
  if { ($TMDBMD == 0) } {
   if { (($TMDdRMS < 0.0) && ($TMDtargetRMS > $TMDfinalRMS)) || (($TMDdRMS > 0.0) && ($TMDtargetRMS < $TMDfinalRMS)) } { 
    set dRMS [expr {$TMDdRMS*$TMDdt/1000.0}];
   } else { 
#    set dRMS [expr {$TMDfinalRMS - $TMDtargetRMS} ] ; #this will take care of out-of-range values of TargetRMS
   }
  } else {
   if { [expr { ($currentRMS - $TMDtargetRMS) * $TMDdRMS}] > 0 } { set dRMS $TMDdRMS }; #ratchet down
  }  
#
# evolve restraint position
  set TMDtargetRMS [expr {$TMDtargetRMS + $dRMS}]; 
#
  if { (( $TMDdK > 0.0 ) &&  ( $TMDk < $TMDfinalK )) || (( $TMDdK < 0.0 ) &&  ( $TMDk > $TMDfinalK )) } {
   set TMDk [expr {$TMDk + $TMDdK*$TMDdt/1000.0}] ; #for gradually increasing/decreasing force constant
  } elseif {$TMDdK !=0.0} {
   set TMDk $TMDfinalK ; # this will take care of out-of-range values of k
  } 
#
#  if { ( $TMDforcesOn == 1) && ( $currentRMS > $TMDtargetRMS ) } {}; # apply force only if currentRMS above targetRMS
  if { ( $TMDforcesOn == 1) } {
   set forceLog [expr {$TMDk * ($currentRMS - $TMDtargetRMS)}]; # this part of the force due to prefactor only (output)
   set force1   [expr {$forceLog/$currentRMS1}];                                # prefactor normalized by first RMSD
   set force2   [expr {$forceLog/$currentRMS2}];                                # prefactor normalized by second RMSD
   addenergy [expr {0.5 * $forceLog * ($currentRMS - $TMDtargetRMS) } ];
#   set TMDwork [expr {$TMDwork - $forceLog * $dRMS }]; #
   set TMDwork [expr {$TMDwork - 0.5 * ($forceLog + $oldForceLog) * $dRMS }]; 
#   set TMDwork [expr {$TMDwork - $oldForceLog * $dRMS }]; # force at previous step
   set oldForceLog $forceLog
#
   if {( $TMDforcesOutFreq > 0) && ( $timestep % $TMDforcesOutFreq == 0 ) } {; #output forces on TMD atoms
#
     foreach atom $TMDatoms {xcur ycur zcur} $currentcoor {xtar1 ytar1 ztar1} $targetcoor1 {xtar2 ytar2 ztar2} $targetcoor2 \
             forceFlag $TMDforcedFlags {
      set pre1 [expr {$force1*$forceFlag}];
      set pre2 [expr {$force2*$forceFlag}];
      set forcevec [concat [expr {$pre1*($xtar1-$xcur) - $pre2*($xtar2-$xcur)}] \
                           [expr {$pre1*($ytar1-$ycur) - $pre2*($ytar2-$ycur)}] \
			   [expr {$pre1*($ztar1-$zcur) - $pre2*($ztar2-$zcur)}]];
      addforce $atom $forcevec
      lappend forcelist $forcevec
     };#foreach
     puts $TMDforcesOut "$timestep \t $forcelist"; flush $TMDforcesOut;
#
   } else {;#timestep
     foreach atom $TMDatoms {xcur ycur zcur} $currentcoor {xtar1 ytar1 ztar1} $targetcoor1 {xtar2 ytar2 ztar2} $targetcoor2 \
             forceFlag $TMDforcedFlags {
      set pre1 [expr {$force1*$forceFlag}];
      set pre2 [expr {$force2*$forceFlag}];
      addforce $atom [concat [expr {$pre1*($xtar1-$xcur) - $pre2*($xtar2-$xcur)}] \
                             [expr {$pre1*($ytar1-$ycur) - $pre2*($ytar2-$ycur)}] \
                             [expr {$pre1*($ztar1-$zcur) - $pre2*($ztar2-$zcur)}]];
     };#foreach
   }; #timestep
#    
  } else {; #TMDforcesOn
    set forceLog 0.0
  }  ; #apply force
  if { $dtimestep % $TMDprintFreq == 0 } { ; #print
#   puts $TMDout "$timestep \t $TMDk \t $forceLog \t $currentRMS \t $TMDtargetRMS \t $TMDfinalRMS \t $TMDwork"; flush $TMDout;
   puts $TMDout \
   [format " %d \t %f \t %f \t %f \t %f \t %f \t %f" \
   $timestep  $TMDk  $forceLog  $currentRMS  $TMDtargetRMS  $TMDfinalRMS  $TMDwork] ;
   flush $TMDout;
  }
#
 } ;# TMDon 
} ;#calcforces
