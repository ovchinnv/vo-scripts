% plot path in dihedral space
%

close;

map=load('adia.dat'); % potential energy map in phi/psi space

phi=map(:,1);
psi=map(:,2);
ene=map(:,3);

n=sqrt(length(phi));
phi=reshape(phi,n,n);
psi=reshape(psi,n,n);
ene=reshape(ene,n,n);

pcolor(phi, psi, ene);shading interp;colorbar;hold on;
xlabel('\phi', 'FontSize',16);
ylabel('\psi', 'FontSize',16);

%return;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% now can overlay paths
name='dihe.dat';
d=load(name);
id=d(:,1);
phi=d(:,2);
psi=d(:,3);
plot(phi, psi,'r.-','MarkerSize',5);
%%%%%%%%%%%%%%%%%%%%%%%%%%
set(gca,'FontSize',16);

%set(gcf, 'paperpositionmode', 'auto');
%print(gcf, '-depsc2', 'surf.eps');
%print(gcf, '-djpeg100', 'surf.jpg');

